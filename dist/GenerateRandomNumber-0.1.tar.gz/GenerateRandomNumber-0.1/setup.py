from setuptools import setup, find_packages

setup(
    name='GenerateRandomNumber',
    version='0.1', packages=find_packages(exclude=['tests']), license='MIT',
    description='GenerateRandomNumber', url='https://github.com/LunarNode/Lab4test.git', author='CanJiang_ValVeeramani',
    author_email='jiang607@purdue.edu'
)